# Build the APK without Android Studio

1. Create/sign in to a GitHub account.
2. Create a new repository, for example `dtcsvks-android`.
3. Upload all files from this project into the repository.
4. Open the repository's **Actions** tab.
5. Select **Build DTC SVKS APK**.
6. Click **Run workflow**.
7. Wait for the build to finish.
8. Open the completed workflow run and download the artifact named **DTC-SVKS-debug-apk**.
9. Extract it and install `app-debug.apk` on the Android phone.

For a production release, a signing key should be created and stored as encrypted GitHub Actions secrets. Do not commit a private signing key or passwords to the repository.
