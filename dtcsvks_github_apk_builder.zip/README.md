# DTC SVKS Android APK Wrapper

Target website: https://dtcsvks.online/

This is a native Android WebView wrapper for the existing website. It supports JavaScript, DOM storage, file selection for website uploads, camera/media permissions requested by the site, external-link handling, and Android back navigation.

Build requirements:
- Android Studio
- Android SDK 35
- JDK 17

Open this folder in Android Studio, allow Gradle sync, then Build > Generate App Bundle / APK > Generate APK.

The website itself remains hosted at dtcsvks.online, so website changes appear in the app without rebuilding the APK.
