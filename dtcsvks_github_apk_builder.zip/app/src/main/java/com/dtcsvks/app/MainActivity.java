package com.dtcsvks.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    WebView web;
    ValueCallback<Uri[]> uploadCallback;
    static final int FILE_REQ=42;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        web=new WebView(this);
        setContentView(web);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v,String url){
                if(url.startsWith("https://dtcsvks.online/") || url.startsWith("https://www.dtcsvks.online/")) return false;
                try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){}
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){
                uploadCallback=cb;
                Intent i=p.createIntent();
                try{startActivityForResult(i,FILE_REQ);}catch(Exception e){uploadCallback=null; return false;}
                return true;
            }
            @Override public void onPermissionRequest(final PermissionRequest r){
                runOnUiThread(()->r.grant(r.getResources()));
            }
        });
        web.loadUrl("https://dtcsvks.online/");
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        if(requestCode==FILE_REQ && uploadCallback!=null){
            Uri[] result=null;
            if(resultCode==RESULT_OK && data!=null){
                if(data.getData()!=null) result=new Uri[]{data.getData()};
                else if(data.getClipData()!=null){
                    int n=data.getClipData().getItemCount(); result=new Uri[n];
                    for(int i=0;i<n;i++) result[i]=data.getClipData().getItemAt(i).getUri();
                }
            }
            uploadCallback.onReceiveValue(result); uploadCallback=null;
        }
        super.onActivityResult(requestCode,resultCode,data);
    }

    @Override public void onBackPressed(){
        if(web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
